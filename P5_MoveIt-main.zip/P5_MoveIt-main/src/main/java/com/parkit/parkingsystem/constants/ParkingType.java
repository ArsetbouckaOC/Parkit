package com.parkit.parkingsystem.constants;

/**
 * Enum Class containing the different type of vehicle
 */
public enum ParkingType {
    CAR,
    BIKE
}
